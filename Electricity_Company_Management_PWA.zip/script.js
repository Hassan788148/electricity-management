
function addEmployee() {
    const name = document.getElementById('employee-name').value;
    const position = document.getElementById('employee-position').value;
    if (name && position) {
        const employeeList = document.getElementById('employee-list');
        const li = document.createElement('li');
        li.textContent = `Name: ${name}, Position: ${position}`;
        employeeList.appendChild(li);
        document.getElementById('employee-form').reset();
    }
}

function addCustomer() {
    const name = document.getElementById('customer-name').value;
    const balance = document.getElementById('customer-balance').value;
    if (name && balance) {
        const customerList = document.getElementById('customer-list');
        const li = document.createElement('li');
        li.textContent = `Name: ${name}, Balance: $${balance}`;
        customerList.appendChild(li);
        document.getElementById('customer-form').reset();
    }
}
